﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
            Person peter = new Person("Peter", 20);
            Console.WriteLine($"{peter.Name} {peter.Age}");
            Person geuorge = new Person("Geuorge",18);
            Console.WriteLine($"{geuorge.Name} {geuorge.Age}");
            Person jose = new Person("Jose", 43);
            Console.WriteLine($"{jose.Name} {jose.Age}");
        }
    }
}
