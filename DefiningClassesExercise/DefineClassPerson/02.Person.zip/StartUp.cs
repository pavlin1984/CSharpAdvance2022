﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person1 = new Person();
            Person perso2 = new Person(12);
            Person person3 = new Person("Pavlin",37);
        }
    }
}
